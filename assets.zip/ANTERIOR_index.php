<?php
header("Status: 301 Moved Permanently");
header("Location: http://localhost/rispro/validacion/login.php");
exit;
?>